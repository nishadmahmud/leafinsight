# Deep Learning-Based Leaf Diseases Detection in Indoor Ornamental Plants: A Full-Stack AI Platform

**Nishad Mahmud Opu, Md Saiful Islam, Ruma Akter, Kazi Maisha Jannath, Shahriar Ahmed, Rakibul Islam Rafi**  
*Sylhet Engineering College / Metropolitan University, Sylhet, Bangladesh*

---

## Abstract
Accurate leaf disease detection in indoor ornamental plants remains a critical challenge due to reliance on subjective visual inspection and the high cost of molecular diagnostics. This project addresses the need for an efficient system to monitor plant health by developing a comprehensive end-to-end platform. The core intelligence leverages modern YOLO architectures (YOLOv8, YOLOv9, and YOLOv11) to identify nine disease and healthy classes across Money, Snake, and Spider Plants, achieving up to 97.4% mAP@50. To bridge the gap between research and real-world application, we engineered a full-stack, Progressive Web App (PWA) with a Next.js frontend and a FastAPI backend. This platform features native mobile camera capture, client-side image compression, and real-time hardware benchmarking. Furthermore, Explainable AI (XAI) techniques, including Occlusion Sensitivity and RISE, were directly integrated into the user interface to ensure trust and transparency in the model's predictions.

---

## 1. Introduction
Plant diseases cause substantial losses in agricultural productivity. While traditional detection methods are subjective and error-prone, deep learning offers rapid, scalable solutions. However, many existing works remain isolated as academic models lacking accessible deployment interfaces and transparency ("black-box" nature). 

This project goes beyond model training by deploying YOLOv11 within a production-ready Web Application. We utilize an augmented dataset of 3,935 images covering three indoor plant species. The resulting platform not only classifies diseases with high precision but also visually explains *why* the model made its decision via integrated XAI heatmaps.

---

## 2. Methodology & Machine Learning

### 2.1 Dataset and Augmentation
A custom dataset of 787 high-resolution images was collected in Sylhet City, capturing Money Plant, Snake Plant, and Spider Plant variations under different lighting conditions. Using Albumentations, the dataset was augmented to 3,935 images via flipping, rotation, zooming, and photometric transformations. The dataset was split 80:10:10 for training, validation, and testing.

### 2.2 YOLO Architectures
We evaluated three state-of-the-art object detection models:
- **YOLOv8s**
- **YOLOv9s**
- **YOLOv11s** (Baseline model featuring C3k2 blocks, SPPF modules, and C2PSA spatial attention).

All models were trained on 640×640 inputs using the AdamW optimizer over 100 epochs.

---

## 3. System Architecture & Web Application

To make the YOLO models accessible, we built a hybrid AI-Web platform known as **LeafInsight**.

### 3.1 Backend (FastAPI)
The inference engine is powered by Python and FastAPI. It loads the PyTorch YOLO weights into memory and exposes RESTful endpoints (`/detect`, `/benchmark`, `/explain`). The backend handles dynamic aspect-ratio letterboxing and calculates bounding boxes and confidence scores in real-time.

### 3.2 Frontend (Next.js & PWA)
The user interface was built using Next.js 16 and TailwindCSS, engineered as a fully installable **Progressive Web App (PWA)**.
- **Mobile-First Experience:** Users can access their native camera directly from the browser (`capture="environment"`).
- **Client-Side Compression:** High-resolution smartphone photos (10MB+) are compressed in the browser via `browser-image-compression` to under 1MB before uploading, ensuring rapid inference on weak networks.
- **Offline Capabilities:** Service workers (via Serwist) aggressively cache the application shell, allowing the UI to load instantly offline.

### 3.3 Explainable AI (XAI) Integration
To address the "black-box" problem, the platform dynamically generates two types of XAI heatmaps upon user request:
- **Occlusion Sensitivity:** Systematically masks regions of the leaf to observe the effect on the prediction.
- **RISE (Randomized Input Sampling for Explanation):** Generates pixel-level contribution maps to highlight exact disease lesions.

These heatmaps are displayed interactively in the web dashboard alongside the standard bounding boxes.

---

## 4. Results & Performance

### 4.1 Quantitative Results
YOLOv11s emerged as the superior model, outperforming its predecessors in both localization and classification reliability on the test set.

| Model | mAP@50 | mAP@50-95 | Precision | Recall |
| --- | --- | --- | --- | --- |
| YOLOv8s | 97.1 | 87.9 | 92.2 | 96.5 |
| YOLOv9s | 96.6 | 87.9 | 92.9 | 96.2 |
| **YOLOv11s** | **97.4** | **89.3** | **93.7** | **96.7** |

![mAP Comparison](images/944ce8e908c4deeeed7c76650af6adef-image.png)

### 4.2 Class-wise Performance
YOLOv11s achieved perfect recall (1.000) for Money Plant Bacterial Wilt, Money Plant Healthy, and Money Plant Manganese Toxicity. Minor confusion was observed between visually similar symptoms, such as Snake Plant Anthracnose and Snake Plant Leaf Withering.

![Confusion Matrix](images/2170dd52fec00de8e34448212b350544-image.png)

### 4.3 Interpretability (XAI)
The generated Occlusion and RISE heatmaps successfully proved that YOLOv11s focuses on relevant botanical features (leaf tissue and lesions) while heavily suppressing background noise.

![XAI Heatmaps](images/4266e009fcfd001dadcc12d748048091-image.png)

---

## 5. Conclusion
This project successfully bridged the gap between academic deep learning research and practical software engineering. By combining the highly accurate YOLOv11s model (97.4% mAP@50) with a modern, PWA-enabled Next.js web application, we created a scalable, mobile-friendly platform for indoor plant disease monitoring. The integration of native camera access, client-side image compression, and interactive XAI heatmaps ensures that the system is not only fast and reliable, but also transparent and trustworthy for end-users.
